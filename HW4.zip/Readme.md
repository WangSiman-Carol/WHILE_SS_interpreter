### requirements
Python 3.77

lark: an open source parser

### compile
make

### run
./while-ss.py
