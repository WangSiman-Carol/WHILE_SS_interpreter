#!/usr/bin/env bash

make
./bin/bats tests/
